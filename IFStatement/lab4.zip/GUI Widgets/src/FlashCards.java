import javax.swing.*;
public class FlashCards {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WidgetViewer wv = new WidgetViewer();
		int num1 = (int)(Math.random()* 10);
		int num2 = (int)(Math.random()*10);
		
		JLabel Question = new JLabel("What is: " + num1 + " + " + num2);
		wv.add(Question, 10, 30, 300, 30);
		
		JTextField iansw = new JTextField();
		wv.add(iansw, 10, 60, 300, 30);
		
		JButton click = new JButton("Click to see result!");
		wv.addAndWait(click);
		
		int answ = Integer.parseInt(iansw.getText());
		int rightAnswer = num1 + num2;
		if(num1 + num2 != answ) {
			
			JLabel Answer = new JLabel("Wrong Answer! The Answer is: " + rightAnswer);
			wv.add(Answer, 10, 80, 300, 30);
		}
			else
			{
				JLabel Answer = new JLabel("Good Answer!");
				wv.add(Answer, 10, 80, 300, 30);
			}
	}

}
