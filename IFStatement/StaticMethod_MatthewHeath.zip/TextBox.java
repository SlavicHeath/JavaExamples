
public class TextBox {
	//prints number of lines of *
		public static String textBoxString(int side)
		{
			String pattern = "";
			for(int k = 0; k<side; k++) {
			for(int i = 0; i<side; i++) {
				pattern += "*";
				
			}
			pattern += "\n";
			}
			
		
			return pattern;
			
		}
		//prints number of lines and selected sign
		public static String textBoxString(int side, char bChar)
		{
			String pattern = "";
			for(int k = 0; k<side; k++) {
			for(int i = 0; i<side; i++)
			{
				pattern += bChar;
				
			}
			pattern +="\n";
			}
			return pattern;
		}
		
		//number of lines is chosen and number of rows
		public static String textBoxString( int cols, int rows) 
		{
			String pattern = "";
			for(int k = 0; k<cols; k++) {
			for(int i = 0; i<rows; i++)
			{
				pattern += "*";
				
			}
			pattern +="\n";
			}
			return pattern;
		}
			
			
			
		//number of rows with names of c1, c2 and number of columns
		public static String textBoxString(int rows, int cols, char c1, char c2)
		{
			String pattern = "";
			for(int k = 0; k<cols; k++) {
			for(int i = 0; i<rows; i++)
			{
				
		    	pattern += c1;
		    	pattern +=c2;
				
			}
			pattern +="\n";
			}
			return pattern;
		}
		    	
	
}
