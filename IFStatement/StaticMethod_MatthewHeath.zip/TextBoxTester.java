
public class TextBoxTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s= TextBox.textBoxString(3);
		System.out.println(s);
		String s1= TextBox.textBoxString(2, '+');
		System.out.println(s1);
		String s2= TextBox.textBoxString(3, 5);
		System.out.println(s2);
		String s3= TextBox.textBoxString(2, 4, 'x', 'o');
		System.out.println(s3);
	}

}
