public class SelectionSortLAb {
    /** The method for sorting the numbers */
    public static void main (String[] args){
    	//define variables
        final int NUM_ELEMENTS=10;
        double[] lo2Hi=new double[NUM_ELEMENTS];
        double[] hi2Lo=new double[NUM_ELEMENTS];
        double[] random=new double[NUM_ELEMENTS];
        
        for (int x=0;x<NUM_ELEMENTS;x++){
            lo2Hi[x]=(x+1);
        }
        
        for (int x=0;x<NUM_ELEMENTS;x++){
            hi2Lo[x]=(NUM_ELEMENTS-x);
        }
        
        for (int x=0;x<NUM_ELEMENTS;x++){
            random[x]=Math.random();
        }
        selectionSort(lo2Hi);
        selectionSort(hi2Lo);
        selectionSort(random);

    }

    public static void selectionSort(double[] list) {
    	//define variables
        int swaps=0;
        int compares=0;
        
        for (int i = 0; i < list.length - 1; i++) {
            // Minimum
            double currentMin = list[i];
            int currentMinIndex = i;
            
            
            for (int j = i + 1; j < list.length; j++) {
                compares +=1;
                
                if (currentMin > list[j]) {
                    currentMin = list[j];
                    currentMinIndex = j;
                }
            }
            // Swap list[i] with list[currentMinIndex] 
            if (currentMinIndex != i) {
                swaps+=1;
                list[currentMinIndex] = list[i];
                list[i] = currentMin;
            }
        }
        
        System.out.print("The size of array is"+ list.length);
        System.out.print(" Number of comparisons:"+compares);
        System.out.print(" Number of data swaps:"+ swaps);
        System.out.println();

    }//selection sort class

}
